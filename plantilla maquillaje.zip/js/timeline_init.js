 var timeline = new TL.Timeline('makeup-history-timeline', 'content/timeline/makeup-timeline.json', {slide_padding_lr: 80, language: "es", use_bc: true});
